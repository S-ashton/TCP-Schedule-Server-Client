package com.mycompany.edptcpclientapp;

import javafx.stage.Stage;

import java.net.UnknownHostException;

public class clientController {
    private final clientModel model;
    private final clientView view;
    String response;

    public clientController(Stage stage) throws UnknownHostException {
        model = new clientModel(1234);
        view = new clientView(stage);
        attachEventHandlers();
    }

    private void attachEventHandlers(){
        view.addClassButton.setOnAction(e -> handleAddCScene());
        view.addButton.setOnAction(e -> handleAddClass());
        view.removeButton.setOnAction(e -> handleRemoveClass());
        view.removeClassButton.setOnAction(e -> handleRemoveScene());
        view.displayButton.setOnAction(e -> handleEnter());
        view.displaySchedButton.setOnAction(e -> handleDisplayScene());
        view.requestEarlyButton.setOnAction(e -> handleRequestEarlyScene());
        view.requestButton.setOnAction(e -> handleRequestEarlyClass());
        view.back.setOnAction(e -> handleBack());
        view.stop.setOnAction(e -> handleStop());
        view.enterButton.setOnAction(e -> handleDisplayClass());
    }

    private void handleAddClass(){
        String className = view.className.getText();
        String classLength = view.classLength.getText();
        String classTime = view.classTime.getText();
        String classRoom = view.classRoom.getText();
        String classDays = view.classDays.getText();
        String classCourse = view.classCourse.getText();
        String response = model.sendMessage("ADD_CLASS" + "," +  className + "," + classTime + "," + classLength + "," + classDays + "," + classRoom + "," + classCourse);
        view.label.setText(response);
        System.out.println(response);
        view.styleUI();
    }

    private void handleAddCScene(){
        view.addClassScene();
        view.styleUI();

    }

    private void handleRemoveScene(){
        view.removeClassScene();
        view.styleUI();

    }

    private void handleRemoveClass(){
        String className = view.className.getText();
        String response = model.sendMessage("REMOVE_CLASS" + className);
        view.label.setText(response);
        view.styleUI();
        ;
    }

    private void handleDisplayClass(){
        String className = view.className.getText();
        String classCourse = view.classCourse.getText();
        this.response = model.sendMessage("DISPLAY_SCHEDULE" + "," + className + "," + classCourse);
        view.label.setText(response);
        view.styleUI();
        System.out.println("DISPLAY_SCHEDULE" + "," + className + "," + classCourse);

    }

    private void handleDisplayScene(){
        view.displayScheduleScene();
        view.styleUI();

    }

    private void handleRequestEarlyClass(){
        String className = view.className.getText();
        String response = model.sendMessage("EARLY_LECTURES" + "," + className);
        view.label.setText(response);
        view.styleUI();

    }

    private void handleRequestEarlyScene(){
        view.requestEarlyScene();
        view.styleUI();

    }

    private void handleBack(){
        view.backScene();
        view.styleUI();

    }

    private void handleStop(){
        model.sendMessage("STOP");
        System.exit(0);

    }

    private void handleEnter(){

        String[] info = model.displayInfo(response);
        int row = model.getRow(info);
        int col = model.getCol(info);
        view.displayGrid(col, row, info[1], info[0], info[3]);
        view.styleUI();


    }


}
