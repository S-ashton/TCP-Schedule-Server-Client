module com.mycompany.edptcpclientapp {
    requires javafx.controls;
    requires jdk.compiler;
    exports com.mycompany.edptcpclientapp;
}
