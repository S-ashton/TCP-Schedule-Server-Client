module com.mycompany.edptcpclientapp {
    requires javafx.controls;
    requires jdk.compiler;
    requires java.desktop;
    exports com.mycompany.edptcpclientapp;
}
