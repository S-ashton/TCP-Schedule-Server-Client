package com.mycompany.edptcpclientapp;

import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;



public class clientView {
    //handles the viewing styling, starting scene, layouts, etc.
    public final Label label = new Label("Response from server: ");
    private final TextField textField = new TextField("");
    public final TextField className = new TextField();
    public final TextField classTime = new TextField();
    public final TextField classLength = new TextField();
    public final TextField classDays = new TextField();
    public final TextField classRoom = new TextField();
    public final TextField classCourse = new TextField();
    public final TextField usernameText = new TextField();
    public final TextField passwordText = new TextField();
    public Button addClassButton = new Button("Add Class");
    public final Button removeClassButton = new Button("Remove Class");
    public final Button displaySchedButton = new Button("Display Schedule");
    public final Button addButton = new Button("Add");
    public final Button removeButton = new Button("Remove");
    public final Button displayButton = new Button("Display");
    public final Button displayByCourseButton = new Button("Display By Course");
    public final Button displayByClassButton = new Button("Display By Class");
    public final Button requestEarlyButton = new Button("Request Earlier Time");
    public final Button requestButton = new Button("Request");
    public final Button enterButton = new Button("Enter");
    public final Button back = new Button("Back");
    public final Button userBack = new Button("Back");
    public final Button stop = new Button("Finish and close");
    public final Button loginButton = new Button("Login");
    public final Button addUserButton = new Button("Add User");
    public final Button addForUser = new Button("Add");
    private final Label cName = new Label("Enter class name: ");
    private final Label cTime = new Label("Enter time of class: ");
    private final Label cLength = new Label("Enter length of class (in minutes): ");
    private final Label cDays = new Label("Enter day(s) of class: ");
    private final Label room = new Label("Enter room(s) for class: ");
    private final Label course = new Label("Enter the course name: ");
    private final Label startLabel = new Label("Please choose your required service.");
    private final Label mon = new Label("Monday");
    private final Label tue = new Label("Tuesday");
    private final Label wed = new Label("Wednesday");
    private final Label thurs = new Label("Thursday");
    private final Label fri = new Label("Friday");
    private final Label nineAM = new Label("09:00");
    private final Label tenAM = new Label("10:00");
    private final Label elevAM = new Label("11:00");
    private final Label twelvAM = new Label("12:00");
    private final Label onePM = new Label("01:00");
    private final Label twoPM = new Label("02:00");
    private final Label threePM = new Label("03:00");
    private final Label fourPM = new Label("04:00");
    private final Label fivePM = new Label("05:00");
    private final Label sixPM = new Label("06:00");
    private final Label userNameLabel = new Label("username :");
    private final Label passwordLabel = new Label("password :");
    private final Label welcomeLabel = new Label("Welcome!");
    //public Label responseLabel = new Label();
    private DropShadow shadow = new DropShadow();
    private String defaultServerResponseLabel = "";

    Stage stage;
    GridPane gPaneDis = new GridPane();
    BorderPane bPBox = new BorderPane();

    public clientView(Stage stage){
        this.stage = stage;
        loginScene();
    }

    public void requestEarlyScene(){

            VBox box = new VBox(cName, className, requestButton, back, label);
            var sceneDisplay = new Scene(box, 740, 580);
            sceneDisplay.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
            sceneDisplay.setFill(Color.SLATEGRAY);
            box.setStyle("-fx-background: linear-gradient(to bottom, #81b1ce, #618394);");
            box.setSpacing(10.0);
            box.setAlignment(Pos.CENTER);
            className.clear();
            stage.setScene(sceneDisplay);
            stage.show();

    }

    public void displayScheduleScene(){
        VBox box = new VBox(cName, className, enterButton, displayButton, back, label);
        box.setStyle("-fx-background: linear-gradient(to bottom, #81b1ce, #618394);");
        box.setSpacing(10.0);
        var display = new Scene(box, 740, 580);
        display.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        box.setAlignment(Pos.CENTER);
        className.clear();
        classCourse.clear();
        stage.setScene(display);
        stage.show();
    }

    public void displayScheduleCourseScene(){
        VBox box = new VBox(course, classCourse, enterButton, displayButton, back, label);
        box.setStyle("-fx-background: linear-gradient(to bottom, #81b1ce, #618394);");
        box.setSpacing(10.0);
        var display = new Scene(box, 740, 580);
        display.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        box.setAlignment(Pos.CENTER);
        className.clear();
        classCourse.clear();
        stage.setScene(display);
        stage.show();
    }

    public void removeClassScene(){
        VBox box = new VBox(cName, className, removeButton, back, label);
        box.setStyle("-fx-background: linear-gradient(to bottom, #81b1ce, #618394);");
        box.setSpacing(10.0);
        var sceneRemoveClass = new Scene(box, 740, 580);
        sceneRemoveClass.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        box.setAlignment(Pos.CENTER);
        className.clear();
        stage.setScene(sceneRemoveClass);
        stage.show();
    }

    public void addClassScene(){
        VBox box = new VBox(cName, className,cLength, classLength, cTime, classTime, room, classRoom, cDays, classDays, course, classCourse, addButton, back, label);
        box.setStyle("-fx-background: #618394;");
        box.setSpacing(10.0);
        var sceneAddClass = new Scene(box, 740, 580);
        sceneAddClass.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        box.setAlignment(Pos.CENTER);
        className.clear();
        classLength.clear();
        classDays.clear();
        classRoom.clear();
        classCourse.clear();
        classTime.clear();
        stage.setScene(sceneAddClass);
        stage.show();
    }

    public void backScene(){
        label.setText(defaultServerResponseLabel);
        VBox box = new VBox(startLabel, addClassButton, removeClassButton, displayByClassButton, displayByCourseButton, requestEarlyButton, stop);
        var sceneStart = new Scene(box, 740, 580);
        sceneStart.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        sceneStart.setFill(Color.SLATEGRAY);
        box.setStyle("-fx-background: linear-gradient(to bottom, #618394, #2e587a);");
        box.setSpacing(10.0);
        box.setAlignment(Pos.CENTER);
        stage.setScene(sceneStart);
        stage.show();
    }

    public void loginScene(){



        VBox box = new VBox(welcomeLabel,userNameLabel, usernameText , passwordLabel, passwordText, loginButton, stop);
        var sceneLogin = new Scene(box, 740, 580);
        sceneLogin.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        box.setStyle("-fx-background: linear-gradient(to bottom, #618394, #2e587a);");

        box.setSpacing(10.0);
        box.setAlignment(Pos.CENTER);
        usernameText.getStyleClass().add("text-field-login-style");
        passwordText.getStyleClass().add("text-field-login-style");
        welcomeLabel.setAlignment(Pos.TOP_LEFT);

        stage.setScene(sceneLogin);
        styleUI();
        stage.show();
    }

    public void adminStartScene(){
        VBox box = new VBox(startLabel, addClassButton, removeClassButton, displayByClassButton, displayByCourseButton, requestEarlyButton, addUserButton, stop);
        var sceneStart = new Scene(box, 740, 580);
        sceneStart.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        box.setStyle("-fx-background: linear-gradient(to bottom, #618394, #2e587a);");
        box.setSpacing(10.0);
        box.setAlignment(Pos.CENTER);
        stage.setScene(sceneStart);
        styleUI();
        stage.show();
    }

    public void userStartScene(){
        VBox box = new VBox(startLabel, addClassButton, displayByClassButton, displayByCourseButton, requestEarlyButton, stop);
        var sceneStart = new Scene(box, 740, 580);
        sceneStart.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        box.setStyle("-fx-background: linear-gradient(to bottom, #618394, #2e587a);");
        box.setSpacing(10.0);
        box.setAlignment(Pos.CENTER);
        stage.setScene(sceneStart);
        styleUI();
        stage.show();
    }

    public void addUserScene(){
        VBox box = new VBox(startLabel, usernameText, passwordText, addForUser, stop);
        var sceneStart = new Scene(box, 740, 580);
        sceneStart.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        box.setStyle("-fx-background: linear-gradient(to bottom, #618394, #2e587a);");
        box.setSpacing(10.0);
        box.setAlignment(Pos.CENTER);
        stage.setScene(sceneStart);
        styleUI();
        stage.show();
    }

    public void displayGrid(){

        var sceneDisplaySched = new Scene(bPBox, 740, 580);
        sceneDisplaySched.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        sceneDisplaySched.setFill(Color.SLATEGRAY);
        bPBox.setStyle("-fx-background: linear-gradient(to bottom, #81b1ce, #618394);");
        bPBox.setMaxWidth(150);
        bPBox.setMaxHeight(100);


        gPaneDis.setGridLinesVisible(true);
        gPaneDis.add(mon, 1,0);
        gPaneDis.add(tue, 2, 0);
        gPaneDis.add(wed, 3, 0);
        gPaneDis.add(thurs, 4, 0);
        gPaneDis.add(fri, 5, 0);
        gPaneDis.add(nineAM, 0, 1);
        gPaneDis.add(tenAM, 0, 2);
        gPaneDis.add(elevAM, 0,3);
        gPaneDis.add(twelvAM, 0, 4);
        gPaneDis.add(onePM, 0, 5);
        gPaneDis.add(twoPM, 0, 6);
        gPaneDis.add(threePM, 0,7);
        gPaneDis.add(fourPM, 0, 8);
        gPaneDis.add(fivePM, 0, 9);
        gPaneDis.add(sixPM, 0, 10);


        gPaneDis.getStyleClass().add("grid");
        gPaneDis.setAlignment(Pos.CENTER);

        bPBox.setCenter(gPaneDis);
        bPBox.setBottom(back);

        back.setAlignment(Pos.CENTER);

        stage.setScene(sceneDisplaySched);
        stage.show();
    }

    public void addToGrid(int col, int row, String day, String name, String room){
        Label classInfoSlot = new Label(name + "\n" + room);
        Label nameOfClass = new Label(name + " weekly timetable");
        bPBox.setTop(nameOfClass);
        nameOfClass.setAlignment(Pos.CENTER);
        classInfoSlot.getStyleClass().add("grid-cell");
        classInfoSlot.getStyleClass().add("second-label-style");
        nameOfClass.getStyleClass().add("label-top");
        gPaneDis.add(classInfoSlot, col, row);
    }

    public void styleUI() {



        addClassButton.getStyleClass().add("button-style");
        removeClassButton.getStyleClass().add("button-second-style");
        displaySchedButton.getStyleClass().add("button-third-style");
        addButton.getStyleClass().add("button-style");
        removeButton.getStyleClass().add("button-second-style");
        displayButton.getStyleClass().add("button-third-style");
        requestEarlyButton.getStyleClass().add("button-third-style");
        requestButton.getStyleClass().add("button-third-style");
        enterButton.getStyleClass().add("button-third-style");
        back.getStyleClass().add("back-stop-button");
        stop.getStyleClass().add("back-stop-button");
        displayByClassButton.getStyleClass().add("button-third-style");
        displayByCourseButton.getStyleClass().add("button-third-style");
        loginButton.getStyleClass().add("button-third-style");

        label.getStyleClass().add("second-label-style");
        userNameLabel.getStyleClass().add("third-label-style");
        passwordLabel.getStyleClass().add("third-label-style");
        cName.getStyleClass().add("second-label-style");
        cTime.getStyleClass().add("second-label-style");
        cLength.getStyleClass().add("second-label-style");
        cDays.getStyleClass().add("second-label-style");
        room.getStyleClass().add("second-label-style");
        course.getStyleClass().add("second-label-style");
        startLabel.getStyleClass().add("label-style");
        welcomeLabel.getStyleClass().add("label-wel");
        mon.getStyleClass().add("grid-header");
        tue.getStyleClass().add("grid-header");
        wed.getStyleClass().add("grid-header");
        thurs.getStyleClass().add("grid-header");
        fri.getStyleClass().add("grid-header");
        nineAM.getStyleClass().add("grid-header");
        tenAM.getStyleClass().add("grid-header");
        elevAM.getStyleClass().add("grid-header");
        twelvAM.getStyleClass().add("grid-header");
        onePM.getStyleClass().add("grid-header");
        twoPM.getStyleClass().add("grid-header");
        threePM.getStyleClass().add("grid-header");
        fourPM.getStyleClass().add("grid-header");
        fivePM.getStyleClass().add("grid-header");
        sixPM.getStyleClass().add("grid-header");



        textField.getStyleClass().add("text-field-style");
        className.getStyleClass().add("text-field-style");
        classLength.getStyleClass().add("text-field-style");
        classDays.getStyleClass().add("text-field-style");
        classRoom.getStyleClass().add("text-field-style");
        classCourse.getStyleClass().add("text-field-style");
        classTime.getStyleClass().add("text-field-style");
        usernameText.getStyleClass().add("text-field-login-style");
        passwordText.getStyleClass().add("text-field-login-style");

        label.setWrapText(true);
    }



}
