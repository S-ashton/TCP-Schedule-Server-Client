package com.mycompany.edptcpclientapp;

import javafx.stage.Stage;

import java.net.UnknownHostException;
import java.util.Arrays;

public class clientController {
    private final clientModel model;
    private final clientView view;
    String response;
    static Boolean admin = true;

    public clientController(Stage stage) throws UnknownHostException {
        model = new clientModel(1234);
        view = new clientView(stage);
        attachEventHandlers();
    }

    private void attachEventHandlers(){
        view.addClassButton.setOnAction(e -> handleAddCScene());
        view.addButton.setOnAction(e -> handleAddClass());
        view.removeButton.setOnAction(e -> handleRemoveClass());
        view.removeClassButton.setOnAction(e -> handleRemoveScene());
        view.displayButton.setOnAction(e -> handleEnter());
        view.displayByClassButton.setOnAction(e -> handleDisplayScene());
        view.requestEarlyButton.setOnAction(e -> handleRequestEarlyScene());
        view.requestButton.setOnAction(e -> handleRequestEarlyClass());
        view.back.setOnAction(e -> handleBack());
        view.stop.setOnAction(e -> handleStop());
        view.enterButton.setOnAction(e -> handleDisplayClass());
        view.displayByCourseButton.setOnAction(e -> handleDisplayCourseScene());
        view.addUserButton.setOnAction(e -> handleAddScene());
        view.loginButton.setOnAction(e -> handleLogin());
        view.userBack.setOnAction(e -> handleUserBack());
        view.addForUser.setOnAction(e -> handleAddUser());
        view.displayCourseButton.setOnAction(e -> handleDisplayCourse());
    }

    private void handleAddClass(){
        String className = view.className.getText();
        String classLength = view.classLength.getText();
        String classTime = view.classTime.getText();
        String classRoom = view.classRoom.getText();
        String classDays = view.classDays.getText();
        String classCourse = view.classCourse.getText();
        String response = model.sendMessage("ADD_CLASS" + "," +  className + "," + classTime + "," + classLength + "," + classDays + "," + classRoom + "," + classCourse);
        view.label.setText(response);
        System.out.println(response);
        view.styleUI();
    }

    private void handleAddCScene(){
        view.addClassScene();
        view.styleUI();

    }

    private void handleRemoveScene(){
        view.removeClassScene();
        view.styleUI();

    }

    private void handleRemoveClass(){
        String className = view.className.getText();
        String response = model.sendMessage("REMOVE_CLASS" + className);
        view.label.setText(response);
        view.styleUI();
        ;
    }

    private void handleDisplayClass(){
        String className = view.className.getText();
        String classCourse = view.classCourse.getText();
        this.response = model.sendMessage("DISPLAY_SCHEDULE" + "," + className + "," + classCourse);
        view.label.setText(response);
        view.styleUI();

    }

    private void handleDisplayCourse(){
        String className = view.className.getText();
        String classCourse = view.classCourse.getText();
        this.response = model.sendMessage("DISPLAY_SCHEDULE_COURSE" + "," + className + "," + classCourse);
        view.label.setText(response);
        view.styleUI();
    }

    private void handleDisplayCourseScene(){
        view.displayScheduleCourseScene();
        view.styleUI();
    }

    private void handleDisplayScene(){
        view.displayScheduleScene();
        view.styleUI();

    }

    private void handleRequestEarlyClass(){
        String className = view.className.getText();
        String response = model.sendMessage("EARLY_LECTURES" + "," + className);
        view.label.setText(response);
        view.styleUI();

    }

    private void handleRequestEarlyScene(){
        view.requestEarlyScene();
        view.styleUI();

    }

    private void handleBack(){
        view.backScene();
        view.styleUI();

    }

    private void handleUserBack(){
        view.backUserScene();
    }

    private void handleStop(){
        model.sendMessage("STOP");
        System.exit(0);

    }

    private void handleEnter(){
        view.displayGrid();
        System.out.println(response);
        String[] classes = response.split("/");
        System.out.println("Multiple Classes Received: " + classes.length);
        System.out.println(Arrays.toString(classes));
        for (int i = 0; i < classes.length; i++) {
            System.out.println("Processing: " + classes[i]); // Debug log
            String[] info = model.displayInfo(classes[i]);
            System.out.println(Arrays.toString(info));
            int row = model.getRow(info);
            int col = model.getCol(info);
            System.out.println("Row: " + row + ", Col: " + col); // Additional debug log

            view.addToGrid(col, row, info[1], info[0], info[3]);
            System.out.println("Updated Grid at Row: " + row + ", Col: " + col + " with: " + Arrays.toString(info));
        }
        view.styleUI();
    }

    private void handleAddUser(){
        String username = view.usernameText.getText();
        String password = view.passwordText.getText();
        String response = model.sendMessage("ADD_USER" + "," + username + "," + password);
        view.label.setText(response);
    }

    private void handleAddScene(){
        view.addUserScene();
        view.styleUI();
    }

    private void handleLogin(){
        String username = view.usernameText.getText();
        String password = view.passwordText.getText();
        String response = model.sendMessage("LOGIN" + "," + username + "," + password);
        view.label.setText(response);

        if(response.equals("USER")){
            admin = false;
            view.userStartScene();
        } else if(response.equals("ADMIN")){
            view.adminStartScene();
            admin = true;
        } else {
            view.label.setText(response);
        }
    }

}
