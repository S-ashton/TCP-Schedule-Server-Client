package com.mycompany.edptcpclientapp;


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;

/**
 * Simple Client app to send and receive information to and from TCP server
 * Handles this through a JavaFX GUI, which is styled using a .css style sheet
 * @author sophi
 */

public class App extends Application {

    @Override
    public void start(Stage stage) throws UnknownHostException {
        clientController controller = new clientController(stage);

    }


    /**
     * launching the app upon "run"
      * @param args
     */
    public static void main(String[] args){
        launch();
    }
}
