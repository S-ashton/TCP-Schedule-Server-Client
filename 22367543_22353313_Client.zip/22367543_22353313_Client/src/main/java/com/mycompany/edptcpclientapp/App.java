package com.mycompany.edptcpclientapp;


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;

/**
 * Simple Client app to send and receive information to and from TCP server
 * Handles this through a JavaFX GUI, which is styled using a .css style sheet
 * @author sophi
 */

public class App extends Application {

    /*
    initialise variables for server and javafx 
    */
    static InetAddress host;
    static final int PORT = 1234;
    private final Label label = new Label("Response from server: ");
    private final TextField textField = new TextField("");
    private final TextField className = new TextField();
    private final TextField classTime = new TextField();
    private final TextField classLength = new TextField();
    private final TextField classDays = new TextField();
    private final TextField classRoom = new TextField();
    private final TextField classCourse = new TextField();
    private final Button button = new Button("Add Class");
    private final Button buttonTwo = new Button("Remove Class");
    private final Button buttonThree = new Button("Display Schedule");
    private final Button buttonFour = new Button("Add");
    private final Button buttonFive = new Button("Remove");
    private final Button buttonSix = new Button("Display");
    private final Button buttonSeven = new Button("Request Earlier Time");
    private final Button buttonEight = new Button("Request");
    private final Button buttonNine = new Button("Enter");
    private final Button back = new Button("Back");
    private final Button stop = new Button("Finish and close");
    private final Label cName = new Label("Enter class name: ");
    private final Label cTime = new Label("Enter time of class: ");
    private final Label cLength = new Label("Enter length of class (in minutes): ");
    private final Label cDays = new Label("Enter day(s) of class: ");
    private final Label room = new Label("Enter room(s) for class: ");
    private final Label course = new Label("Enter the course name: ");
    private final Label startLabel = new Label("Please choose your required service.");
    private final Label mon = new Label("Monday");
    private final Label tue = new Label("Tuesday");
    private final Label wed = new Label("Wednesday");
    private final Label thurs = new Label("Thursday");
    private final Label fri = new Label("Friday");
    private final Label nineAM = new Label("09:00");
    private final Label tenAM = new Label("10:00");
    private final Label elevAM = new Label("11:00");
    private final Label twelvAM = new Label("12:00");
    private final Label onePM = new Label("01:00");
    private final Label twoPM = new Label("02:00");
    private final Label threePM = new Label("03:00");
    private final Label fourPM = new Label("04:00");
    private final Label fivePM = new Label("05:00");
    private final Label sixPM = new Label("06:00");
    private DropShadow shadow = new DropShadow();
    private final String defaultServerResponseLabel = "";
    private String serverResponse = "";


    /**
     *
     * @param stage the primary stage for this application, onto which
     * the application scene can be set.
     * Applications may create other stages, if needed, but they will not be
     * primary stages.
     */
    public void start (Stage stage){



        buttonFour.setOnAction(new EventHandler<ActionEvent>(){
            /**
             * buttonFour handles the ADD_CLASS case for server interaction
             * sends a message to the server with class information provided by the user
             * @param a the event which occurred
             */
            @Override
            public void handle(ActionEvent a){
                try
                {
                    host = InetAddress.getLocalHost();
                }
                catch(UnknownHostException e)
                {
                    System.out.println("Host ID not found.");
                    System.exit(1);
                }
                Socket link = null;
                try
                {
                    link = new Socket(host,PORT);
                    BufferedReader in = new BufferedReader(new InputStreamReader (link.getInputStream()));
                    PrintWriter out = new PrintWriter(link.getOutputStream(), true);
                    
                    String message = null;
                    String response = null;
                    
                    System.out.println("Enter message to be sent to server: ");
                    message = ("ADD_CLASS" + "," + (className.getText().toString()) + "," + (classTime.getText().toString()) + "," + (classLength.getText().toString()) + "," +
                           (classDays.getText().toString()) + "," + (classRoom.getText().toString() + "," + classCourse.getText()));
                    
                    out.println(message);
                    out.flush();
                    response = in.readLine();
                    label.setText(response);
                    
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    try
                    {
                        System.out.println("\n* Closing connection... *");
                        link.close();
                    }catch(IOException e)
                    {
                        System.out.println("Unable to disconnect.");
                        System.exit(1);
                    }
                }
            }
        });
        
        buttonFive.setOnAction(new EventHandler<ActionEvent>(){
            /**
             * buttonFive handles the REMOVE_CLASS case for server interaction
             * sends information on which class to remove to server according to user input
             * @param b the event which occurred
             */
            @Override
            public void handle(ActionEvent b){
                try
                {
                    host = InetAddress.getLocalHost();
                }
                catch(UnknownHostException e)
                {
                    System.out.println("Host ID not found.");
                    System.exit(1);
                }
                Socket link = null;
                try
                {
                    
                    link = new Socket(host,PORT);
                    BufferedReader in = new BufferedReader(new InputStreamReader (link.getInputStream()));
                    PrintWriter out = new PrintWriter(link.getOutputStream(), true);
                    
                    String message = null;
                    String response = null;
                    
                    System.out.println("Enter message to be sent to server: ");
                    message = ("REMOVE_CLASS," + (className.getText().toString()));
                    out.println(message);
                    response = in.readLine();
                    label.setText(response);
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    try
                    {
                        System.out.println("\n* Closing connection... *");
                        link.close();
                    }catch(IOException e)
                    {
                        System.out.println("Unable to disconnect.");
                        System.exit(1);
                    }
                }
            }
        });

        buttonNine.setOnAction(new EventHandler<ActionEvent>(){
            /**
             * buttonNine handles the enter button for DISPLAY case for server interaction
             * sends information on which class to remove to server according to user input
             * @param b the event which occurred
             */
            @Override
            public void handle(ActionEvent b){
                try
                {
                    host = InetAddress.getLocalHost();
                }
                catch(UnknownHostException e)
                {
                    System.out.println("Host ID not found.");
                    System.exit(1);
                }
                Socket link = null;
                try
                {

                    link = new Socket(host,PORT);
                    BufferedReader in = new BufferedReader(new InputStreamReader (link.getInputStream()));
                    PrintWriter out = new PrintWriter(link.getOutputStream(), true);

                    String message = null;
                    String response = null;
                    StringBuilder responseBuilder = new StringBuilder();

                    System.out.println("Enter message to be sent to server: ");
                    message = ("DISPLAY_SCHEDULE," + (className.getText().toString()) + "," + (classCourse.getText().toString()));
                    out.println(message);
                    System.out.println(message);

                    /*
                    // Read lines in a loop until an empty line is encountered
                    String line;
                    int lineNumber = 1;
                    while ((line = in.readLine()) != null && !line.isEmpty()) {
                        responseBuilder.append(line).append("\n");
                        System.out.println("Received line " + lineNumber + ": " + line);
                        lineNumber++;
                    }
                    */


                    // Set the response to the label
                    //response = responseBuilder.toString();


                    response = in.readLine();
                    label.setText(response);
                    System.out.println(response);

                    serverResponse = response;

                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    try
                    {
                        System.out.println("\n* Closing connection... *");
                        link.close();
                    }catch(IOException e)
                    {
                        System.out.println("Unable to disconnect.");
                        System.exit(1);
                    }
                }
            }
        });


        buttonSix.setOnAction(new EventHandler<ActionEvent>(){
            /**
             * buttonSix handles the DISPLAY_SCHEDULE case for server interaction
             * displays associated information for class input by user
             * @param c the event which occurred
             */



            @Override
            public void handle(ActionEvent c){
                try
                {
                    host = InetAddress.getLocalHost();
                }
                catch(UnknownHostException e)
                {
                    System.out.println("Host ID not found.");
                    System.exit(1);
                }
                Socket link = null;
                try
                {
                    BorderPane bPBox = new BorderPane();
                    var sceneDisplaySched = new Scene(bPBox, 740, 580);
                    sceneDisplaySched.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
                    sceneDisplaySched.setFill(Color.SLATEGRAY);
                    bPBox.setStyle("-fx-background: linear-gradient(to bottom, #81b1ce, #618394);");
                    bPBox.setMaxWidth(150);
                    bPBox.setMaxHeight(100);

                    GridPane gPaneDis = new GridPane();
                    gPaneDis.setGridLinesVisible(true);
                    gPaneDis.add(mon, 1,0);
                    gPaneDis.add(tue, 2, 0);
                    gPaneDis.add(wed, 3, 0);
                    gPaneDis.add(thurs, 4, 0);
                    gPaneDis.add(fri, 5, 0);
                    gPaneDis.add(nineAM, 0, 1);
                    gPaneDis.add(tenAM, 0, 2);
                    gPaneDis.add(elevAM, 0,3);
                    gPaneDis.add(twelvAM, 0, 4);
                    gPaneDis.add(onePM, 0, 5);
                    gPaneDis.add(twoPM, 0, 6);
                    gPaneDis.add(threePM, 0,7);
                    gPaneDis.add(fourPM, 0, 8);
                    gPaneDis.add(fivePM, 0, 9);
                    gPaneDis.add(sixPM, 0, 10);

                    //gPaneDis.getStyleClass().add("-grid");
                    gPaneDis.getStyleClass().add("grid");
                    gPaneDis.setAlignment(Pos.CENTER);

                    bPBox.setCenter(gPaneDis);
                    bPBox.setBottom(back);

                    link = new Socket(host,PORT);
                    BufferedReader in = new BufferedReader(new InputStreamReader (link.getInputStream()));
                    PrintWriter out = new PrintWriter(link.getOutputStream(), true);

                    //change this to error code or null or something, server can send back error code and
                    //client can print message or server can send back error message and this will just match it
                    //as it does currently
                   /*
                    if(response.equals( "Error: no classes to display")) {
                        label.setText(response);
                    } else {
                    */

                        //message = "className,dayOfClass,timeOfClass,roomClassIn
                        //this can be changed to suit server :)
                        String[] classInfo = serverResponse.split(",");

                        int col = 0;
                        int row = 0;
                        String sTime = classInfo[2];
                        String[] timeParts = sTime.split(":");
                        int time = Integer.parseInt(timeParts[0]);

                        //setting the column to suit the correct day
                        if(classInfo[1].equals("Monday")){
                            col = 1;
                        } else if(classInfo[1].equals("Tuesday")){
                            col = 2;
                        } else if(classInfo[1].equals("Wednesday")){
                            col = 3;
                        } else if(classInfo[1].equals("Thursday")){
                            col = 4;
                        } else {
                            col = 5;
                        }

                        //setting the row to suit the correct time
                        if(time == 9){
                            row = 1;
                        } else if(time == 10){
                            row = 2;
                        } else if(time == 11){
                            row = 3;
                        } else if(time == 12){
                            row = 4;
                        } else if(time == 1){
                            row = 5;
                        } else if(time == 2){
                            row = 6;
                        } else if(time == 3){
                            row = 7;
                        } else if(time == 4){
                            row = 8;
                        } else if(time == 5){
                            row = 9;
                        } else if(time == 6){
                            row = 10;
                        }

                        Label classInfoSlot = new Label(classInfo[0] + "\n" + classInfo[3]);
                        Label nameOfClass = new Label(classInfo[0] + " weekly timetable");
                        nameOfClass.setAlignment(Pos.CENTER);
                        back.setAlignment(Pos.CENTER);

                        nameOfClass.getStyleClass().add("label-top");

                        bPBox.setTop(nameOfClass);
                        //classInfoSlot.getStyleClass().add("-second-label-style");
                        classInfoSlot.getStyleClass().add("grid-cell");
                        gPaneDis.add(classInfoSlot, col, row);


                    stage.setScene(sceneDisplaySched);
                    stage.show();

                    className.clear();

                    //System.out.println(classInfo.toString());

                    //}
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    try
                    {
                        System.out.println("\n* Closing connection... *");
                        link.close();
                    }catch(IOException e)
                    {
                        System.out.println("Unable to disconnect.");
                        System.exit(1);
                    }
                }
            }
        });



        stop.setOnAction(new EventHandler<ActionEvent>(){
            /**
             * stop sends a STOP code to the server to signal to close the connection and then exits the java app
             * @param b the event which occurred
             */
            @Override
            public void handle(ActionEvent b){
                try
                {
                    host = InetAddress.getLocalHost();
                }
                catch(UnknownHostException e)
                {
                    System.out.println("Host ID not found.");
                    System.exit(1);
                }
                Socket link = null;
                try
                {
                    
                    link = new Socket(host,PORT);
                    BufferedReader in = new BufferedReader(new InputStreamReader (link.getInputStream()));
                    PrintWriter out = new PrintWriter(link.getOutputStream(), true);
                    
                    String message = null;
                    String response = null;
                    
                    System.out.println("Enter message to be sent to server: ");
                    message = ("STOP");
                    out.println(message);
                    response = in.readLine();
                    label.setText(response);
                    System.exit(0);
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    try
                    {
                        System.out.println("\n* Closing connection... *");
                        link.close();
                    }catch(IOException e)
                    {
                        System.out.println("Unable to disconnect.");
                        System.exit(1);
                    }
                }
            }
        });

        buttonEight.setOnAction(new EventHandler<ActionEvent>(){
            /**
             * buttonSeven handles the EARLY_LECTURES case for server interaction
             * sends a message to the server with class information provided by the user
             * @param a the event which occurred
             */
            @Override
            public void handle(ActionEvent a){
                try
                {
                    host = InetAddress.getLocalHost();
                }
                catch(UnknownHostException e)
                {
                    System.out.println("Host ID not found.");
                    System.exit(1);
                }
                Socket link = null;
                try
                {
                    link = new Socket(host,PORT);
                    BufferedReader in = new BufferedReader(new InputStreamReader (link.getInputStream()));
                    PrintWriter out = new PrintWriter(link.getOutputStream(), true);

                    String message = null;
                    String response = null;


                    message = ("EARLY_LECTURES" + "," + (className.getText().toString()));

                    out.println(message);
                    out.flush();
                    response = in.readLine();

                        label.setText(response);


                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    try
                    {
                        System.out.println("\n* Closing connection... *");
                        link.close();
                    }catch(IOException e)
                    {
                        System.out.println("Unable to disconnect.");
                        System.exit(1);
                    }
                }
            }
        });

        back.setOnAction(new EventHandler<ActionEvent>(){
            /**
             * back allows the user to go back to the main start page to choose a new service
             * it re-builds the start scene
             * @param back the event which occurred
             */
            @Override
            public void handle(ActionEvent back){
                label.setText(defaultServerResponseLabel);
                VBox box = new VBox(startLabel, button, buttonTwo, buttonThree, stop);
                var sceneStart = new Scene(box, 740, 580);
                sceneStart.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
                sceneStart.setFill(Color.SLATEGRAY);
                box.setStyle("-fx-background: linear-gradient(to bottom, #618394, #2e587a);");
                box.setSpacing(10.0);
                box.setAlignment(Pos.CENTER);
                stage.setScene(sceneStart);
                stage.show();
            }
        });

        button.setOnAction(new EventHandler<ActionEvent>(){
            /**
             * button builds the ADD_CLASS scene so that the user may add a class to the server
             * @param a the event which occurred
             */
            @Override
            public void handle(ActionEvent a){
                VBox box = new VBox(cName, className,cLength, classLength, cTime, classTime, room, classRoom, cDays, classDays, course, classCourse, buttonFour, back, label);
                    box.setStyle("-fx-background: #618394;");
                    box.setSpacing(10.0);
                    var sceneAddClass = new Scene(box, 740, 580);
                    sceneAddClass.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
                    box.setAlignment(Pos.CENTER);
                    className.clear();
                    classLength.clear();
                    classDays.clear();
                    classRoom.clear();
                    classCourse.clear();
                    classTime.clear();
                    stage.setScene(sceneAddClass);
                    stage.show(); 
            }
        }
        );

        buttonTwo.setOnAction(new EventHandler<ActionEvent>(){
            /**
             * buttonTwo builds the REMOVE_CLASS scene so that the user may enter a class to be removed
             * @param a the event which occurred
             */
            @Override
            public void handle(ActionEvent a){
               VBox box = new VBox(cName, className, buttonFive, back, label);
                    box.setStyle("-fx-background: linear-gradient(to bottom, #81b1ce, #618394);");
                    box.setSpacing(10.0);
                    var sceneRemoveClass = new Scene(box, 740, 580);
                    sceneRemoveClass.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
                    box.setAlignment(Pos.CENTER);
                    className.clear();
                    stage.setScene(sceneRemoveClass);
                    stage.show(); 
            }
        }
        );

        buttonThree.setOnAction(new EventHandler<ActionEvent>(){
                                  /**
                                   * buttonThree builds the DISPALY_SCHEDULE scene so that the user may enter a class to displayed
                                   * @param a the event which occurred
                                   */
                                  @Override
                                  public void handle(ActionEvent a){
                                      VBox box = new VBox(cName, className, buttonNine, buttonSix, back, label);
                                      box.setStyle("-fx-background: linear-gradient(to bottom, #81b1ce, #618394);");
                                      box.setSpacing(10.0);
                                      var display = new Scene(box, 740, 580);
                                      display.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
                                      box.setAlignment(Pos.CENTER);
                                      className.clear();
                                      stage.setScene(display);
                                      stage.show();
                                  }
                              }
        );



        buttonSeven.setOnAction(new EventHandler<ActionEvent>(){
                                    /**
                                     * buttonSeven builds the EARLY_LECTURES scene so that the user may see the information of a class sent by the server
                                     * @param a the event which occurred
                                     */
                                    @Override
                                    public void handle(ActionEvent a){
                                        VBox box = new VBox(cName, className, buttonSix, back, label);
                                        var sceneDisplay = new Scene(box, 740, 580);
                                        sceneDisplay.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
                                        sceneDisplay.setFill(Color.SLATEGRAY);
                                        box.setStyle("-fx-background: linear-gradient(to bottom, #81b1ce, #618394);");
                                        box.setSpacing(10.0);
                                        box.setAlignment(Pos.CENTER);
                                        className.clear();
                                        stage.setScene(sceneDisplay);
                                        stage.show();
                                    }
                                }
        );


        /*
         * initialising the opening start scene for the app
         */
        VBox box = new VBox(startLabel, button, buttonTwo, buttonThree, buttonSeven, stop);
        var sceneStart = new Scene(box, 740, 580);
        sceneStart.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        box.setStyle("-fx-background: linear-gradient(to bottom, #618394, #2e587a);");
        box.setSpacing(10.0);
        box.setAlignment(Pos.CENTER);
        stage.setScene(sceneStart);
        stage.show();

        /*
         * applying the css stylesheet to the buttons, labels and text fields
         */
        button.getStyleClass().add("button-style");
        buttonTwo.getStyleClass().add("button-second-style");
        buttonThree.getStyleClass().add("button-third-style");
        buttonFour.getStyleClass().add("button-style");
        buttonFive.getStyleClass().add("button-second-style");
        buttonSix.getStyleClass().add("button-third-style");
        buttonSeven.getStyleClass().add("button-third-style");
        buttonEight.getStyleClass().add("button-third-style");
        buttonNine.getStyleClass().add("button-third-style");
        back.getStyleClass().add("back-stop-button");
        stop.getStyleClass().add("back-stop-button");

        label.getStyleClass().add("second-label-style");
        cName.getStyleClass().add("second-label-style");
        cTime.getStyleClass().add("second-label-style");
        cLength.getStyleClass().add("second-label-style");
        cDays.getStyleClass().add("second-label-style");
        room.getStyleClass().add("second-label-style");
        course.getStyleClass().add("second-label-style");
        startLabel.getStyleClass().add("label-style");
        mon.getStyleClass().add("grid-header");
        tue.getStyleClass().add("grid-header");
        wed.getStyleClass().add("grid-header");
        thurs.getStyleClass().add("grid-header");
        fri.getStyleClass().add("grid-header");
        nineAM.getStyleClass().add("grid-header");
        tenAM.getStyleClass().add("grid-header");
        elevAM.getStyleClass().add("grid-header");
        twelvAM.getStyleClass().add("grid-header");
        onePM.getStyleClass().add("grid-header");
        twoPM.getStyleClass().add("grid-header");
        threePM.getStyleClass().add("grid-header");
        fourPM.getStyleClass().add("grid-header");
        fivePM.getStyleClass().add("grid-header");
        sixPM.getStyleClass().add("grid-header");


        textField.getStyleClass().add("text-field-style");
        className.getStyleClass().add("text-field-style");
        classLength.getStyleClass().add("text-field-style");
        classDays.getStyleClass().add("text-field-style");
        classRoom.getStyleClass().add("text-field-style");
        classCourse.getStyleClass().add("text-field-style");
        classTime.getStyleClass().add("text-field-style");

        label.setWrapText(true);

        }

    /**
     * launching the app upon "run"
      * @param args
     */
    public static void main(String[] args){
        launch();
    }
}
