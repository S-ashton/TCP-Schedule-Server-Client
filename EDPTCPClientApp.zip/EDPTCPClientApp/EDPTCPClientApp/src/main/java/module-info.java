module com.mycompany.edptcpclientapp {
    requires javafx.controls;
    exports com.mycompany.edptcpclientapp;
}
