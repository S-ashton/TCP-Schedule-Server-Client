package com.mycompany.edptcpclientapp;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;


public class clientModel {
    //handles the logic inside the button presses so controller can just call method when button pressed

    private InetAddress host;
    private final int PORT;

    /**
     * starts the model with the server's port
     * @param port
     * @throws UnknownHostException
     */
    public clientModel(int port) throws UnknownHostException {
        this.PORT = port;
        this.host = InetAddress.getLocalHost();

    }

    /**
     * sends the message to the server and reads back in the server's response
     * @param message
     * @return
     */
    public String sendMessage(String message){
        try (Socket link = new Socket(host, PORT);
             PrintWriter out = new PrintWriter(link.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(link.getInputStream()))) {

            out.println(message);
            //System.out.println(in.readLine());
            return in.readLine();

        } catch (IOException e) {
            System.out.println("Error communicating with the server: " + e.getMessage());
            return null;
        }
    }

    /**
     * processes server's response for displaying schedule in GUI
     * @param message
     * @return
     */
    public String[] displayInfo(String message){
        String[] classInfo = message.split(",");
        System.out.println(Arrays.toString(classInfo));
       return classInfo;
    }

    /**
     * uses part of server's processed response to set the correct column for displaying on the timetable
     * @param info
     * @return
     */
    public int getCol(String[] info){
        int col = 0;

        String sTime = info[2];
        String[] timeParts = sTime.split(":");
        int time = Integer.parseInt(timeParts[0]);

        //setting the column to suit the correct day
        if(info[1].equals("Monday")){
            col = 1;
        } else if(info[1].equals("Tuesday")){
            col = 2;
        } else if(info[1].equals("Wednesday")){
            col = 3;
        } else if(info[1].equals("Thursday")){
            col = 4;
        } else {
            col = 5;
        }

        return col;
    }

    /**
     * uses part of server's processed response to set the correct row on the timetable
     * @param info
     * @return
     */
    public int getRow(String[] info){

        if(info.length < 3){
            System.out.println("Error, expected 3 elements, given : " + info.length);
        }


        int row = 0;
        String sTime = info[2];
        String[] timeParts = sTime.split(":");
        int time = Integer.parseInt(timeParts[0]);

        if(time == 9){
            row = 1;
        } else if(time == 10){
            row = 2;
        } else if(time == 11){
            row = 3;
        } else if(time == 12){
            row = 4;
        } else if(time == 13){
            row = 5;
        } else if(time == 14){
            row = 6;
        } else if(time == 15){
            row = 7;
        } else if(time == 16){
            row = 8;
        } else if(time == 17){
            row = 9;
        } else if(time == 18){
            row = 10;
        }

        return row;
    }

}
