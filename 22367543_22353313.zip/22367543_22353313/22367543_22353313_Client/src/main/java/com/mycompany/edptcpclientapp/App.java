package com.mycompany.edptcpclientapp;


import javafx.application.Application;

import javafx.stage.Stage;

import java.net.UnknownHostException;


/**
 * Simple Client app to send and receive information to and from TCP server
 * Handles this through a JavaFX GUI, which is styled using a .css style sheet
 * @author sophi
 */

public class App extends Application {

    @Override
    public void start(Stage stage) throws UnknownHostException {
        clientController controller = new clientController(stage);

    }


    /**
     * launching the app upon "run"
      * @param args
     */
    public static void main(String[] args){
        launch();
    }
}
