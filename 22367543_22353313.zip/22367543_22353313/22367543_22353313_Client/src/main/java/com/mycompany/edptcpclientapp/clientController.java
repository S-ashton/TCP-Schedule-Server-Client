package com.mycompany.edptcpclientapp;

import javafx.stage.Stage;

import javax.swing.*;
import java.net.UnknownHostException;
import java.util.Arrays;

public class clientController {
    private final clientModel model;
    private final clientView view;
    String response;
    static Boolean admin = true;
    Boolean courseDisplay = false;

    /**
     *initialises the controller to start the model and view and attack the event handlers to the buttons
     * @param stage
     * @throws UnknownHostException
     */
    public clientController(Stage stage) throws UnknownHostException {
        model = new clientModel(1234);
        view = new clientView(stage);
        attachEventHandlers();
    }

    /**
     *attaches event handlers to each corresponding button
     */
    private void attachEventHandlers(){
        view.addClassButton.setOnAction(e -> handleAddCScene());
        view.addButton.setOnAction(e -> handleAddClass());
        view.removeButton.setOnAction(e -> handleRemoveClass());
        view.removeClassButton.setOnAction(e -> handleRemoveScene());
        view.displayButton.setOnAction(e -> handleEnter());
        view.displayByClassButton.setOnAction(e -> handleDisplayScene());
        view.requestEarlyButton.setOnAction(e -> handleRequestEarlyScene());
        view.requestButton.setOnAction(e -> handleRequestEarlyClass());
        view.back.setOnAction(e -> handleBack());
        view.stop.setOnAction(e -> handleStop());
        view.enterButton.setOnAction(e -> handleDisplayClass());
        view.displayByCourseButton.setOnAction(e -> handleDisplayCourseScene());
        view.addUserButton.setOnAction(e -> handleAddScene());
        view.loginButton.setOnAction(e -> handleLogin());
        view.userBack.setOnAction(e -> handleUserBack());
        view.addForUser.setOnAction(e -> handleAddUser());
        view.displayCourseButton.setOnAction(e -> handleDisplayCourse());
    }

    /**
     *sends ADD_CLASS message to server with relevant class details in order to add a class to the server
     */
    private void handleAddClass(){
        String className = view.className.getText();
        String classLength = view.classLength.getText();
        String classTime = view.classTime.getText();
        String classRoom = view.classRoom.getText();
        String classDays = view.classDays.getText();
        String classCourse = view.classCourse.getText();
        String response = model.sendMessage("ADD_CLASS" + "," +  className + "," + classTime + "," + classLength + "," + classDays + "," + classRoom + "," + classCourse);
        view.label.setText(response);
        System.out.println(response);
        view.styleUI();
    }

    /**
     *calls method to create scene for adding a class
     */
    private void handleAddCScene(){
        view.addClassScene();
        view.styleUI();

    }

    /**
     *calls method to create scene for removing a class
     */
    private void handleRemoveScene(){
        view.removeClassScene();
        view.styleUI();

    }

    /**
     *sends REMOVE_CLASS message to server to request to remove a class from the server
     */
    private void handleRemoveClass(){
        String className = view.className.getText();
        String response = model.sendMessage("REMOVE_CLASS" + "," + className);
        view.label.setText(response);
        view.styleUI();
        ;
    }

    /**
     *sends DISPLAY_SCHEDULE message to the server to request the information to display all associated class times
     * with the given class
     */
    private void handleDisplayClass(){
        String className = view.className.getText();
        String classCourse = view.classCourse.getText();
        this.response = model.sendMessage("DISPLAY_SCHEDULE" + "," + className + "," + classCourse);
        view.label.setText(response);
        view.styleUI();

    }

    /**
     *sends DISPLAY_SCHEDULE_COURSE message to the server to request the information to display all classes
     * in a course
     */
    private void handleDisplayCourse(){
        courseDisplay = true;

        String classCourse = view.classCourse.getText();
        this.response = model.sendMessage("DISPLAY_SCHEDULE_COURSE" + "," + classCourse);
        view.label.setText(response);
        view.styleUI();
    }


    /**
     *calls method to create scene for selecting a course to display
     */
    private void handleDisplayCourseScene(){
        view.displayScheduleCourseScene();
        view.styleUI();
    }

    /**
     *calls method to create scene for selecting a class to display
     */
    private void handleDisplayScene(){
        view.displayScheduleScene();
        view.styleUI();

    }

    /**
     *sends EALRY_LECTURES message to server to request an earlier time for given class
     */
    private void handleRequestEarlyClass(){
        String className = view.className.getText();
        String response = model.sendMessage("EARLY_LECTURES" + "," + className);
        view.progressBar.setVisible(true);
        view.label.setText(response);

        Timer timer = new Timer(10000, event -> {
            view.progressBar.setVisible(false);
            view.label.setText("Task Complete");
        });
        timer.setRepeats(false);
        timer.start();

        view.styleUI();

    }

    /**
     *calls method to create scene for requesting earlier lecture times
     */
    private void handleRequestEarlyScene(){
        view.requestEarlyScene();
        view.styleUI();

    }

    /**
     *calls method to create scene for admins pressing of back
     */
    private void handleBack(){
        view.backScene();
        view.styleUI();

    }

    /**
     *calls method to create scene for user's pressing of back
     */
    private void handleUserBack(){
        view.backUserScene();
    }

    /**
     *sends STOP message to server to initiate termination
     */
    private void handleStop(){
        model.sendMessage("STOP");
        System.exit(0);

    }

    /**
     *adds the classes to their appropriate rows and columns in the gridPane to display the schedule
     */
    private void handleEnter(){
        view.displayGrid();
        System.out.println(response);
        String course = view.classCourse.getText();
        String[] classes = response.split("/");
        System.out.println("Multiple Classes Received: " + classes.length);
        System.out.println(Arrays.toString(classes));
        for (int i = 0; i < classes.length; i++) {
            System.out.println("Processing: " + classes[i]); // Debug log
            String[] info = model.displayInfo(classes[i]);
            System.out.println(Arrays.toString(info));
            int row = model.getRow(info);
            int col = model.getCol(info);
            System.out.println("Row: " + row + ", Col: " + col); // Additional debug log

            view.addToGrid(col, row, info[1], info[0], info[3],course, courseDisplay);
            System.out.println("Updated Grid at Row: " + row + ", Col: " + col + " with: " + Arrays.toString(info));
        }
        view.styleUI();
    }

    /**
     *sends ADD_USER message, and it's relevant information to sever
     */
    private void handleAddUser(){
        String username = view.usernameText.getText();
        String password = view.passwordText.getText();
        String response = model.sendMessage("ADD_USER" + "," + username + "," + password);
        view.label.setText(response);
    }

    /**
     *calls method to create scene for Add User
     */
    private void handleAddScene(){
        view.addUserScene();
        view.styleUI();
    }

    /**
     *sends appropriate login messgae to server and sets the value for admin to decide what GUI to start
     */
    private void handleLogin(){
        String username = view.usernameText.getText();
        String password = view.passwordText.getText();
        String response = model.sendMessage("LOGIN" + "," + username + "," + password);
        view.label.setText(response);

        if(response.equals("USER")){
            admin = false;
            view.userStartScene();
        } else if(response.equals("ADMIN")){
            view.adminStartScene();
            admin = true;
        } else {
            view.label.setText(response);
        }
    }

}
