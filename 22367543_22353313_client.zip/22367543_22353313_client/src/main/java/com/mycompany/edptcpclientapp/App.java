package com.mycompany.edptcpclientapp;


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 *Simple Client app to send and receive information to and from TCP server
 * Handles this through a JavaFX GUI, which is styled using a .css style sheet
 * @author sophi
 */
public class App extends Application {

    /*
    initialise variables for server and javafx 
    */
    static InetAddress host;
    static final int PORT = 1234;
    private final Label label = new Label("Response from server: ");
    private final TextField textField = new TextField("");
    private final TextField className = new TextField();
    private final TextField classTime = new TextField();
    private final TextField classLength = new TextField();
    private final TextField classDays = new TextField();
    private final TextField classRoom = new TextField();
    private final TextField classCourse = new TextField();
    private final Button button = new Button("Add Class");
    private final Button buttonTwo = new Button("Remove Class");
    private final Button buttonThree = new Button("Display Schedule");
    private final Button buttonFour = new Button("Add");
    private final Button buttonFive = new Button("Remove");
    private final Button buttonSix = new Button("Display");
    private final Button back = new Button("Back");
    private final Button stop = new Button("Finish and close");
    private final Label cName = new Label("Enter class name: ");
    private final Label cTime = new Label("Enter time of class: ");
    private final Label cLength = new Label("Enter length of class: ");
    private final Label cDays = new Label("Enter day(s) of class: ");
    private final Label room = new Label("Enter room(s) for class: ");
    private final Label course = new Label("Enter the course name: ");
    private final Label startLabel = new Label("Please choose your required service.");
    private DropShadow shadow = new DropShadow();
    private final String defaultServerResponseLabel = "Response from server: ";
        
    

   
    
    
    public void start (Stage stage){
        
        
        
        
        
        buttonFour.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent a){
                try
                {
                    host = InetAddress.getLocalHost();
                }
                catch(UnknownHostException e)
                {
                    System.out.println("Host ID not found.");
                    System.exit(1);
                }
                Socket link = null;
                try
                {
                    link = new Socket(host,PORT);
                    BufferedReader in = new BufferedReader(new InputStreamReader (link.getInputStream()));
                    PrintWriter out = new PrintWriter(link.getOutputStream(), true);
                    
                    String message = null;
                    String response = null;
                    
                    System.out.println("Enter message to be sent to server: ");
                    message = ("ADD_CLASS" + "," + (className.getText().toString()) + "," + (classTime.getText().toString()) + "," + (classLength.getText().toString()) + "," +
                           (classDays.getText().toString()) + "," + (classRoom.getText().toString() + "," + classCourse.getText()));
                    
                    out.println(message);
                    out.flush();
                    response = in.readLine();
                    label.setText(response);
                    
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    try
                    {
                        System.out.println("\n* Closing connection... *");
                        link.close();
                    }catch(IOException e)
                    {
                        System.out.println("Unable to disconnect.");
                        System.exit(1);
                    }
                }
            }
        });
        
        buttonFive.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent b){
                try
                {
                    host = InetAddress.getLocalHost();
                }
                catch(UnknownHostException e)
                {
                    System.out.println("Host ID not found.");
                    System.exit(1);
                }
                Socket link = null;
                try
                {
                    
                    link = new Socket(host,PORT);
                    BufferedReader in = new BufferedReader(new InputStreamReader (link.getInputStream()));
                    PrintWriter out = new PrintWriter(link.getOutputStream(), true);
                    
                    String message = null;
                    String response = null;
                    
                    System.out.println("Enter message to be sent to server: ");
                    message = ("REMOVE_CLASS," + (cName.getText().toString()));
                    out.println(message);
                    response = in.readLine();
                    label.setText(response);
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    try
                    {
                        System.out.println("\n* Closing connection... *");
                        link.close();
                    }catch(IOException e)
                    {
                        System.out.println("Unable to disconnect.");
                        System.exit(1);
                    }
                }
            }
        });
        
        buttonSix.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent c){
                try
                {
                    host = InetAddress.getLocalHost();
                }
                catch(UnknownHostException e)
                {
                    System.out.println("Host ID not found.");
                    System.exit(1);
                }
                Socket link = null;
                try
                {
                    
                    link = new Socket(host,PORT);
                    BufferedReader in = new BufferedReader(new InputStreamReader (link.getInputStream()));
                    PrintWriter out = new PrintWriter(link.getOutputStream(), true);
                    
                    String message = null;
                    String response = null;
                    String line1 = "";
                    String line2 = "";
                    String line3 = "";
                    
                    System.out.println("Enter message to be sent to server: ");
                    message = ("DISPLAY_SCHEDULE," + (className.getText().toString()) + "," + (classCourse.getText().toString()));
                    out.println(message);

                    line1 = in.readLine();
                    line2 = in.readLine();
                    line3 = in.readLine();
                    response = line1 + "\n" + line2 + "\n "+ "\n" + line3;

                    System.out.println("Received line 1: " + line1);
                    System.out.println("Received line 2: " + line2);
                    System.out.println("Received line 3: " + line3);

                    label.setText(response);
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    try
                    {
                        System.out.println("\n* Closing connection... *");
                        link.close();
                    }catch(IOException e)
                    {
                        System.out.println("Unable to disconnect.");
                        System.exit(1);
                    }
                }
            }
        });
        
        stop.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent b){
                try
                {
                    host = InetAddress.getLocalHost();
                }
                catch(UnknownHostException e)
                {
                    System.out.println("Host ID not found.");
                    System.exit(1);
                }
                Socket link = null;
                try
                {
                    
                    link = new Socket(host,PORT);
                    BufferedReader in = new BufferedReader(new InputStreamReader (link.getInputStream()));
                    PrintWriter out = new PrintWriter(link.getOutputStream(), true);
                    
                    String message = null;
                    String response = null;
                    
                    System.out.println("Enter message to be sent to server: ");
                    message = ("STOP");
                    out.println(message);
                    response = in.readLine();
                    label.setText(response);
                    System.exit(0);
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    try
                    {
                        System.out.println("\n* Closing connection... *");
                        link.close();
                    }catch(IOException e)
                    {
                        System.out.println("Unable to disconnect.");
                        System.exit(1);
                    }
                }
            }
        });

        /*
        re-initialising start scene when pressing back button
         */
        back.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent back){
                label.setText(defaultServerResponseLabel);
                VBox box = new VBox(startLabel, button, buttonTwo, buttonThree, stop);
                var sceneStart = new Scene(box, 740, 580);
                sceneStart.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
                sceneStart.setFill(Color.SLATEGRAY);
                box.setStyle("-fx-background: linear-gradient(to bottom, #618394, #2e587a);");
                box.setSpacing(10.0);
                box.setAlignment(Pos.CENTER);
                stage.setScene(sceneStart);
                stage.show();
            }
        });

        /*
        setting scene for adding class
         */
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent a){
                VBox box = new VBox(cName, className,cLength, classLength, cTime, classTime, room, classRoom, cDays, classDays, course, classCourse, buttonFour, back, label);
                    box.setStyle("-fx-background: #618394;");
                    box.setSpacing(10.0);
                    var sceneAddClass = new Scene(box, 740, 580);
                    sceneAddClass.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
                    box.setAlignment(Pos.CENTER);
                    stage.setScene(sceneAddClass);
                    stage.show(); 
            }
        }
        );

        /*
        setting scene for removing class
         */
        buttonTwo.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent a){
               VBox box = new VBox(cName, className, buttonFive, back, label);
                    box.setStyle("-fx-background: linear-gradient(to bottom, #81b1ce, #618394);");
                    box.setSpacing(10.0);
                    var sceneRemoveClass = new Scene(box, 740, 580);
                    sceneRemoveClass.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
                    box.setAlignment(Pos.CENTER);
                    stage.setScene(sceneRemoveClass);
                    stage.show(); 
            }
        }
        );

        /*
        setting scene for displaying schedule
         */
        buttonThree.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent a){
               VBox box = new VBox(cName, className, buttonSix, back, label);
                 var sceneDisplay = new Scene(box, 740, 580);
                 sceneDisplay.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
                 sceneDisplay.setFill(Color.SLATEGRAY);
                 box.setStyle("-fx-background: linear-gradient(to bottom, #81b1ce, #618394);");
                 box.setSpacing(10.0);
                 box.setAlignment(Pos.CENTER);
                 stage.setScene(sceneDisplay);
                 stage.show(); 
            }
        }
        );
        
        
       
        /*
        setting initial start window
        */
        VBox box = new VBox(startLabel, button, buttonTwo, buttonThree, stop);
        var sceneStart = new Scene(box, 740, 580);
        sceneStart.getStylesheets().add(getClass().getResource("/clientStyling.css").toExternalForm());
        box.setStyle("-fx-background: linear-gradient(to bottom, #618394, #2e587a);");
        box.setSpacing(10.0);
        box.setAlignment(Pos.CENTER);
        stage.setScene(sceneStart);
        stage.show();
        
        /*
        styling buttons, text fields and labels using css style sheet
        */

        button.getStyleClass().add("button-style");
        buttonTwo.getStyleClass().add("button-second-style");
        buttonThree.getStyleClass().add("button-third-style");
        buttonFour.getStyleClass().add("button-style");
        buttonFive.getStyleClass().add("button-second-style");
        buttonSix.getStyleClass().add("button-third-style");
        back.getStyleClass().add("back-stop-button");
        stop.getStyleClass().add("back-stop-button");

        label.getStyleClass().add("second-label-style");
        cName.getStyleClass().add("second-label-style");
        cTime.getStyleClass().add("second-label-style");
        cLength.getStyleClass().add("second-label-style");
        cDays.getStyleClass().add("second-label-style");
        room.getStyleClass().add("second-label-style");
        course.getStyleClass().add("second-label-style");
        startLabel.getStyleClass().add("label-style");

        textField.getStyleClass().add("text-field-style");
        className.getStyleClass().add("text-field-style");
        classLength.getStyleClass().add("text-field-style");
        classDays.getStyleClass().add("text-field-style");
        classRoom.getStyleClass().add("text-field-style");
        classCourse.getStyleClass().add("text-field-style");
        classTime.getStyleClass().add("text-field-style");

        label.setWrapText(true);

        }
    
    public static void main(String[] args){
        launch();
    }
}
