package com.server1;

/**
 * ClassInfo class for storing class details
 */
public class ClassInfo {
    private String time;
    String day;
    String room;
    String name;
    /**
     * Constructor for ClassInfo.
     *
     * @param day  The day of the class
     * @param time The time of the class
     * @param room The room of the class
     */


    /**
     * Getter for the day of the class.
     *
     * @return The day of the class
     */
    public String day() {
        return day;
    }

    /**
     * Getter for the time of the class.
     *
     * @return The time of the class
     */

    public String time() {
        return time;
    }

    /**
     * Getter for the room of the class.
     *
     * @return The room of the class
     */

    public String room() {
        return room;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setDay(String day) {this.day = day;
    }

    public void setRoom(String room) {this.room = room;
    }

    public String name() {return name;
    }
    public void setName(String name) {this.name = name;
    }

}
