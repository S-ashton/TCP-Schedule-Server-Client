/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.tcpserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * The TCPServer class represents a simple TCP server that manages a schedule of classes.
 * It listens for client connections, receives messages from clients, processes them, and sends responses.
 *
 * The server uses a static ServerSocket to accept connections and manages a scheduleData HashMap
 * to store class information.
 *
 * @author marshmallow
 */

class IncorrectActionException extends Exception {
    public IncorrectActionException(String message) {
        super(message);
    }
}

class ActionClassNotFoundException extends Exception {
    public ActionClassNotFoundException(String message) {
        super(message);
    }
}
//}
// better def in notes making a class Serializable in Java enables its objects to be converted into a byte stream, 
//facilitating features like object persistence, network communication, and more.
// Define a ClassInfo class for storing class details
class ClassInfo implements Serializable {
    private static final long serialVersionUID = 1L;

    private String date;
    private String time;
    private String room;
    private String length;

    public ClassInfo(String date, String time, String room, String length) {
        this.date = date;
        this.time = time;
        this.room = room;
        this.length = length;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getRoom() {
        return room;
    }
      public String getlength() {
        return length;
    }
}


public class TCPServer {

  private static ServerSocket servSock;
  private static final int PORT = 1234;
  private static int clientConnections = 0;
  private static HashMap<String, List<ClassInfo>> scheduleData;

public TCPServer() {
        scheduleData = new HashMap<>();
    }
 /**
     * The main method that initializes and runs the TCPServer.
     *
     * @param args Command-line arguments (unused)
     */
  public static void main(String[] args) {
        TCPServer instance = new TCPServer();
   
    System.out.println("Opening port...\n");
    try 
    {
        servSock = new ServerSocket(PORT);      //Step 1.
    }
    catch(IOException e) 
    {
         System.out.println("Unable to attach to port!");
         System.exit(1);
    }
    
    do 
    {
         instance.run();
    }while (true);

  }
    /**
     * The run method is responsible for handling client connections, receiving messages,
     * processing them, and sending responses back to clients.
     */
  private void run()
  {
    Socket link = null;                        //Step 2.
    try 
    {
      link = servSock.accept();               //Step 2.
      clientConnections++;
      BufferedReader in = new BufferedReader( new InputStreamReader(link.getInputStream())); //Step 3.
      PrintWriter out = new PrintWriter(link.getOutputStream(),true); //Step 3.
      
       String clientMessage;
                while ((clientMessage = in.readLine()) != null) {
                    System.out.println("Message received from client: " + clientConnections + "  " + clientMessage);

                    // Process client message
                    String ServerResponse = processClientMessage(clientMessage);

                    // Send response to the client
                    out.print (ServerResponse);

                    // Check for termination condition
                    if (ServerResponse.equals("TERMINATE")) {
                        break;
                    }
                }
              //Step 4.
     }
    catch(IOException e)
    {
        e.printStackTrace();
    }
    finally 
    {
       try {
	    System.out.println("\n* Closing connection... *");
            link.close();				    //Step 5.
	}
       catch(IOException e)
       {
            System.out.println("Unable to disconnect!");
	    System.exit(1);
       }
    }
  }
    /**
     * Processes the client's message and returns the server's response.
     *
     * @param clientMessage The message received from the client
     * @return The server's response to the client
     */
  public String processClientMessage(String clientMessage) {
    String[] messageParts = clientMessage.split(",");
    String action = messageParts[0].trim();

    try {
        switch (action) {
            case "ADD_CLASS":
                System.out.print ("add class received");
                if (messageParts.length == 6) {
                    String className = messageParts[1].trim();
                    String date = messageParts[2].trim();
                    String time = messageParts[3].trim();
                    String room = messageParts[4].trim();
                    String length = messageParts[5].trim();

                    if (!scheduleData.containsKey(className)) {
                        scheduleData.put(className, new ArrayList<>());
                    }

                    List<ClassInfo> classes = scheduleData.get(className);

                    if (!hasClash(classes, date, time, room)) {
                        classes.add(new ClassInfo(date, time, room, length));
                        return "Class added successfully.";
                    } else {
                        throw new IncorrectActionException("Class scheduling clash.");
                    }
                } else {
                    throw new IncorrectActionException("Invalid ADD_CLASS format.");
                }

            case "REMOVE_CLASS":
                 System.out.print ("remove class received");
                if (messageParts.length == 2) {
                    String classNameToRemove = messageParts[1].trim();

                    if (scheduleData.containsKey(classNameToRemove)) {
                        List<ClassInfo> classes = scheduleData.get(classNameToRemove);

                        if (!classes.isEmpty()) {
                            ClassInfo removedClass = classes.remove(0);

                            String freedTimeSlot = "Freed time slot: " + removedClass.getDate() + " " +
                                    removedClass.getTime() + " in room " + removedClass.getRoom();

                            return freedTimeSlot;
                        } else {
                            throw new IncorrectActionException("No classes to remove for " + classNameToRemove);
                        }
                    } else {
                        throw new IncorrectActionException("Class not found: " + classNameToRemove);
                    }

                } else {
                    throw new IncorrectActionException("Invalid REMOVE_CLASS format.");
                }

            case "DISPLAY_SCHEDULE":
                 System.out.print ("display schedule received");
                if (messageParts.length == 2) {
                    String classNameToDisplay = messageParts[1].trim();

                    if (scheduleData.containsKey(classNameToDisplay)) {
                        List<ClassInfo> classes = scheduleData.get(classNameToDisplay);

                        StringBuilder scheduleDisplay = new StringBuilder();
                        for (ClassInfo classInfo : classes) {
                            scheduleDisplay.append("Class: ").append(classNameToDisplay)
                                    .append(", Date: ").append(classInfo.getDate())
                                    .append(", Time: ").append(classInfo.getTime())
                                    .append(", Room: ").append(classInfo.getRoom()).append("\n");
                        }

                        // Print schedule to console (as per requirement)
                        System.out.println(scheduleDisplay.toString());

                        return "Schedule displayed successfully.";
                    } else {
                        throw new IncorrectActionException("Class not found: " + classNameToDisplay);
                    }

                } else {
                    throw new IncorrectActionException("Invalid DISPLAY_SCHEDULE format.");
                }

            case "STOP":
                return "TERMINATE";

            default:
                throw new IncorrectActionException("Invalid action.");
        }
    } catch (IncorrectActionException e) {
        return e.getMessage();
    }
}
     /**
     * Checks for scheduling clashes in the given list of classes.
     *
     * @param classes List of classes to check for clashes
     * @param date    Date of the class
     * @param time    Time of the class
     * @param room    Room of the class
     * @return True if there is a clash, false otherwise
     */
    private boolean hasClash(List<ClassInfo> classes, String date, String time, String room) {
        // Implementation of logic to check for scheduling clash
        // assume there is a clash if the class has the same date, time, and room
        for (ClassInfo classInfo : classes) {
            if (classInfo.getDate().equals(date) && classInfo.getTime().equals(time) && classInfo.getRoom().equals(room)) {
                return true; // Clash found
            }
        }
        return false; // No clash
    }
}
