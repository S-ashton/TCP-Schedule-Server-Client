
package com.server1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.lang.System.out;

/**
 * The TCPServer class represents a simple TCP server that manages a schedule of classes.
 * It listens for client connections, receives messages from clients, processes them, and sends responses.
 * The server uses a static ServerSocket to accept connections and manages a scheduleData HashMap
 * to store class information.
 * @author marshmallow
 */

class IncorrectActionException extends Exception {
    public IncorrectActionException(String message) {
        super(message);
    }
}

class ActionClassNotFoundException extends Exception {
    public ActionClassNotFoundException(String message) {
        super(message);
    }
}

/**
 * The Server1 class represents the main server application that handles client connections.
 * It uses a static ServerSocket to listen for connections, processes client messages, and sends responses.
 */

public class Server1 {
    private static final int PORT = 1234;
    private static final Logger LOGGER = Logger.getLogger(Server1.class.getName());
    private final ExecutorService executorService = Executors.newCachedThreadPool();
    private static ServerSocket servSock;
    private final Map<String, List<ClassInfo>> scheduleData = new HashMap<>();
    private final Map<String, String> adminCredentials = new HashMap<>();
    private final Map<String, String> userCredentials = new HashMap<>();
    public Server1() {
    }

    public void run() {
        try {
            servSock = new ServerSocket(PORT);
            System.out.println("Server started on port " + PORT);

            while (true) {
                Socket clientSocket = servSock.accept();
                System.out.println("Client connected!");
                executorService.execute(new ClientHandler(clientSocket));
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        Server1 instance = new Server1();

        System.out.println("Opening port on " + PORT + "...\n");
        try {
            instance.run();
        } catch (Exception e) {
            System.out.println("Unable to attach to port!");
            System.exit(1);
        }
    }

    class ClientHandler implements Runnable {
        private final Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())), true)) {

                String clientMessage;
                while ((clientMessage = in.readLine()) != null) {
                    String response = processClientMessage(clientMessage);
                    out.println(response);
                    if (response.equals("TERMINATE")) {
                        break;
                    }
                }

            } catch (IOException e) {
                System.err.println("Error handling client: " + clientSocket + " - " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                } catch (IOException e) {
                    LOGGER.severe("Unable to disconnect: " + e.getMessage());
                }
            }
        }

        private String loadCSVFile(String fileName) {
            StringBuilder content = new StringBuilder();
            try (InputStream inputStream = getClass().getResourceAsStream("/" + fileName)) {
                if (inputStream != null) {
                    LOGGER.info("CSV file found: " + fileName); // Log statement added
                    try (Scanner scanner = new Scanner(new InputStreamReader(inputStream))) {
                        while (scanner.hasNextLine()) {
                            String line = scanner.nextLine();
                            content.append(line.replace(",", ""));
                        }
                    }
                } else {
                    throw new FileNotFoundException("File not found: " + fileName);
                }
            } catch (IOException e) {
                LOGGER.warning("Error loading CSV file: " + e.getMessage()); // Log error
                LOGGER.log(Level.SEVERE, "Exception occurred", e); // Log the exception with severe level
                // Handle the exception appropriately (e.g., log an error, terminate the program)
            }


            return content.toString();
        }
        private void storeAdminCredentials(String username, String password) {
            adminCredentials.put(username, password);
        }

        private void storeUserCredentials(String username, String password) {
            userCredentials.put(username, password);
        }
        // Method to process login action
        private String processLogin(String username, String password) {
            // Check if username exists in admin credentials
            if (adminCredentials.containsKey(username)) {
                // Check if password matches
                if (adminCredentials.get(username).equals(password)) {
                    return "ADMIN"; // Return "ADMIN" if login successful
                }
            }
            // Check if username exists in user credentials
            else if (userCredentials.containsKey(username)) {
                // Check if password matches
                if (userCredentials.get(username).equals(password)) {
                    return "USER"; // Return "USER" if login successful
                }
            }
            // Return error message if login fails
            return "Login failed. Username or password incorrect.";
        }
        /**
         * Processes the client's message and returns the server's response.
         *
         * @param clientMessage The message received from the client
         * @return The server's response to the client
         */
        public synchronized String processClientMessage(String clientMessage) {
            String[] messageParts = clientMessage.split(",");
            String action = messageParts[0].trim();

            try {
                switch (action) {
                    case "LOGIN":
                        // Check if login request has correct format
                        if (messageParts.length == 3) {
                            String username = messageParts[1].trim();
                            String password = messageParts[2].trim();
                            return processLogin(username, password);
                        } else {
                            throw new IncorrectActionException("Invalid LOGIN format.");
                        }
                    case "ADD_USER":
                        // Check if add user request has correct format
                        if (messageParts.length == 3) {
                            String username = messageParts[1].trim();
                            String password = messageParts[2].trim();
                            storeUserCredentials(username, password); // Store user credentials
                            return "User added successfully.";
                        } else {
                            throw new IncorrectActionException("Invalid ADD_USER format.");
                        }
                    case "ADD_CLASS":
                        out.print("add class request received");
                        if (messageParts.length == 7) {
                            String className = messageParts[1].trim();
                            String time = messageParts[2].trim();
                            String length = messageParts[3].trim();
                            String Day = messageParts[4].trim();
                            String room = messageParts[5].trim();
                            String course = messageParts[6].trim();

                            // Validate day, time, and room
                            validateDay(Day);
                            validateTime(time);
                            validateRoom(room);
                            validateCourseCode(course);
                            validateClassLength(length);

                            if (!scheduleData.containsKey(className)) {
                                scheduleData.put(className, new ArrayList<>());
                            }

                            List<ClassInfo> classes = scheduleData.get(className);

                            if (!hasClash(classes, Day, time, room)) {
                                // Create a new instance of ClassInfo using the zero-argument constructor
                                ClassInfo newClass = new ClassInfo(); // Ensure ClassInfo constructor takes zero arguments
                                // Set the properties of the new ClassInfo object
                                newClass.setDay(Day);
                                newClass.setTime(time);
                                newClass.setRoom(room);

                                // Add the new class to the list of classes
                                classes.add(newClass);
                                out.println("Schedule Data after adding class: " + scheduleData);  // debug
                                return "Class added successfully.";

                            } else {
                                throw new IncorrectActionException("Class scheduling clash.");
                            }
                        } else {
                            throw new IncorrectActionException("Invalid ADD_CLASS format.");
                        }

                    case "REMOVE_CLASS":
                        out.print("remove class received");
                        if (messageParts.length == 2) {
                            String classNameToRemove = messageParts[1].trim();

                            if (scheduleData.containsKey(classNameToRemove)) {
                                out.println("Schedule Data before removing class: " + scheduleData);

                                List<ClassInfo> classes = scheduleData.get(classNameToRemove);

                                if (!classes.isEmpty()) {
                                    ClassInfo removedClass = classes.remove(0);

                                    return "Freed time slot: " + removedClass.day() + " " +
                                            removedClass.time() + " in room " + removedClass.room();
                                } else {
                                    throw new IncorrectActionException("No classes to remove for " + classNameToRemove);
                                }
                            } else {
                                throw new IncorrectActionException("Class not found: " + classNameToRemove);
                            }

                        } else {
                            throw new IncorrectActionException("Invalid REMOVE_CLASS format.");
                        }

                    case "DISPLAY_SCHEDULE":

                        if (messageParts.length == 2) {
                            String classNameToDisplay = messageParts[1].trim();

                            LOGGER.info("Displaying schedule for class: " + classNameToDisplay); // Log message


                            out.println("Class name: " + classNameToDisplay);

                            if (scheduleData.containsKey(classNameToDisplay)) {
                                List<ClassInfo> classes = scheduleData.get(classNameToDisplay);
                                List<String> scheduleList = new ArrayList<>();
                                for (ClassInfo classInfo : classes) {
                                    scheduleList.add(String.format("%s,%s,%s,%s",
                                            classNameToDisplay, classInfo.day(), classInfo.time(), classInfo.room()));
                                }

                                // Return comma separated list using join
                                return String.join("/", scheduleList);
                            } else {
                                throw new IncorrectActionException("Class not found: " + classNameToDisplay);
                            }

                        } else {
                            throw new IncorrectActionException("Invalid DISPLAY_SCHEDULE format.");
                        }
                        case "DISPLAY_SCHEDULE_COURSE":
                            if (messageParts.length == 2)
                            {
                                String courseNameToDisplay = messageParts[1].trim();
                                LOGGER.info("Displaying schedule for course: " + courseNameToDisplay); // Log message

                                out.println("Course name: " + courseNameToDisplay);

                                isValidCourseCode(courseNameToDisplay); // Validate course code

                                if (scheduleData.containsKey(courseNameToDisplay)) {
                                    List<ClassInfo> classes = scheduleData.get(courseNameToDisplay);
                                    List<String> scheduleList = new ArrayList<>();
                                    for (ClassInfo classInfo : classes) {
                                        scheduleList.add(String.format("%s,%s,%s,%s",
                                                classInfo.name(), classInfo.day(), classInfo.time(), classInfo.room()));
                                    }

                                    // Return comma-separated list using join
                                    return String.join("/", scheduleList);
                                } else {
                                    throw new IncorrectActionException("Course code not found: " + courseNameToDisplay);
                                }

                            } else {
                                throw new IncorrectActionException("Invalid DISPLAY_SCHEDULE_COURSE format.");
                            }
                    case "EARLY_LECTURES":
                        if (messageParts.length == 2) {
                            String day = messageParts[1].trim();
                            List<ClassInfo> classesForDay = scheduleData.getOrDefault(day, new ArrayList<>());
                            EarlyLecturesTask earlyLecturesTask = new EarlyLecturesTask(day, classesForDay);
                            ForkJoinPool pool = new ForkJoinPool();
                            pool.invoke(earlyLecturesTask);
                            return scheduleData.toString();
                        } else {
                            return "Invalid EARLY_LECTURES format.";
                        }

                    case "STOP":
                        return "TERMINATE";

                    default:
                        throw new ActionClassNotFoundException("Action not recognised: " + action);
                }
            } catch (IncorrectActionException | ActionClassNotFoundException e) {
                return e.getMessage();
            }
        }

        public class EarlyLecturesTask extends RecursiveAction {
            private final String day;
            private final List<ClassInfo> classesForDay;
            private static final int THRESHOLD = 2; // Adjust threshold as needed

            public EarlyLecturesTask(String day, List<ClassInfo> classesForDay) {
                this.day = day;
                this.classesForDay = classesForDay;
            }

            @Override
            protected void compute() {
                // Add logging statement to track task execution
                System.out.println("Computing EarlyLecturesTask...");

                if (classesForDay.size() <= THRESHOLD) {
                    // Add logging statement to track direct execution
                    System.out.println("Shifting classes directly: " + classesForDay.toString());

                    shiftClassesToEarlyMorning(classesForDay.toString());
                } else {
                    // Split the task into smaller subtasks
                    List<EarlyLecturesTask> subtasks = createSubtasks();
                    for (EarlyLecturesTask subtask : subtasks) {
                        subtask.fork(); // Asynchronously execute subtask
                        // Add logging statement to track subtask execution
                        System.out.println("Subtask executed: " + subtask);
                    }
                }
            }

            private List<EarlyLecturesTask> createSubtasks() {
                List<EarlyLecturesTask> subtasks = new ArrayList<>();

                // Determine the number of chunks based on the threshold
                int chunkSize = (int) Math.ceil((double) classesForDay.size() / THRESHOLD);

                // Split the classesForDay list into smaller chunks
                for (int i = 0; i < classesForDay.size(); i += chunkSize) {
                    int end = Math.min(i + chunkSize, classesForDay.size());
                    List<ClassInfo> chunk = classesForDay.subList(i, end);
                    subtasks.add(new EarlyLecturesTask(day, new ArrayList<>(chunk)));
                }

                return subtasks;
            }


            private boolean isBetween(String time, String startTime, String endTime) {
                return time.compareTo(startTime) >= 0 && time.compareTo(endTime) < 0;
            }

            private synchronized void shiftClassesToEarlyMorning(String day) {
                List<ClassInfo> classesForDay = scheduleData.getOrDefault(day, new ArrayList<>());

                // Define the earliest available start time for early morning classes
                String earlyMorningStartTime = "09:00";

                // Iterate through the possible time slots starting from the earliest (9:00 AM)
                for (int hour = 9; hour <= 18; hour++) {
                    // Construct the time string for the current hour
                    String potentialStartTime = String.format("%02d:00", hour);

                    // Check if any classes are already scheduled during the potential time slot
                    boolean slotOccupied = classesForDay.stream()
                            .anyMatch(classInfo -> isBetween(classInfo.time(), potentialStartTime, "18:00"));

                    // If the time slot is not occupied, shift the classes to start at this time
                    if (!slotOccupied) {
                        // Calculate the shift hours based on the difference between the potential start time and 9:00 AM
                        int shiftHours = hour - 9;

                        // Synchronize access to the classesForDay list to prevent concurrent modification issues
                        synchronized (classesForDay) {
                            // Iterate over the classes for the specified day and shift their start times
                            for (ClassInfo classInfo : classesForDay) {
                                // Shift the class start time by the calculated duration
                                String[] timeParts = classInfo.time().split(":");
                                int classHour = Integer.parseInt(timeParts[0]) + shiftHours;
                                String newTime = String.format("%02d:%s", classHour, timeParts[1]);
                                // Update the class start time directly using the setTime method
                                classInfo.setTime(newTime);
                            }
                        }
                        // Break the loop once the classes have been shifted
                        break;
                    }
                }
            }
        }


        /**
         * Checks for scheduling clashes in the given list of classes
         *
         * @param classes List of classes to check for clashes
         * @param Day     Day of the class
         * @param time    Time of the class
         * @param room    Room of the class
         * @return True if there is a clash, false otherwise
         * @throws IncorrectActionException If there is an incorrect action
         */
        private synchronized boolean hasClash(List<ClassInfo> classes, String Day, String time, String room) throws
                IncorrectActionException {
            validateRoom(room); // Validate room first

            // Check for scheduling clash
            for (ClassInfo classInfo : classes) {
                if (classInfo.day().equals(Day) && classInfo.time().equals(time) && classInfo.room().equals(room)) {
                    return true; // Clash found
                }
            }

            return false; // No clash
        }


        // Validate if course code is a valid code from the list of 150 course codes
        private boolean isValidCourseCode(String courseCode) {
            String courseCodesContent = loadCSVFile("course-codes.csv");
            return courseCodesContent.contains(courseCode);
        }

        /**
         * Validate if course code is a valid code from the list of 150 course codes.
         *
         * @param courseCode The course code to validate
         * @throws IncorrectActionException If the course code is invalid
         */
        private void validateCourseCode(String courseCode) throws IncorrectActionException {
            if (!isValidCourseCode(courseCode)) {
                throw new IncorrectActionException("Invalid course code. Please choose a valid course code.");
            }
        }

        // Validate if room is a valid room code from the list of 200 rooms
        private boolean isValidRoom(String room) {
            String roomCodesContent = loadCSVFile("room-code.csv");
            return roomCodesContent.contains(room);
        }

        /**
         * Validate if room is a valid room code from the list of 200 rooms.
         *
         * @param room The room code to validate
         * @throws IncorrectActionException If the room code is invalid
         */
        private void validateRoom(String room) throws IncorrectActionException {
            if (!isValidRoom(room)) {
                throw new IncorrectActionException("Invalid room code. Please choose a valid room code.");
            }
        }

        /**
         * Checks if the given day is valid (Monday to Friday).
         */
        private void validateDay(String Day) {
            String[] validDays = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
            for (String validDay : validDays) {
                if (validDay.equalsIgnoreCase(Day)) {
                    return;
                }
            }
        }

        /**
         * Validate the length of the class.
         *
         * @param classLength The class length to validate
         * @throws IncorrectActionException If the class length is invalid
         */

        private void validateClassLength(String classLength) throws IncorrectActionException {
            try {
                int classLengthValue = Integer.parseInt(classLength);

                // Validate that the class length is within the desired range (30 to 180)
                if (classLengthValue < 30 || classLengthValue > 180) {
                    throw new IncorrectActionException("Class length must be between 30 and 180 minutes.");
                }

                // Validate that the class length is in intervals of 30
                if (classLengthValue % 30 != 0) {
                    throw new IncorrectActionException("Class length must be in intervals of 30 minutes.");
                }
            } catch (NumberFormatException e) {
                throw new IncorrectActionException("Invalid class length format. Please provide a valid integer.");
            }
        }

        /**
         * Checks if the given time is valid (between 8 am and 8 pm).
         *
         * @param time The time to validate
         * @throws IncorrectActionException If the time is invalid
         */
        private void validateTime(String time) throws IncorrectActionException {
            try {
                int hour = Integer.parseInt(time.split(":")[0]);
                int minute = Integer.parseInt(time.split(":")[1].split(" ")[0]);

                // Check if the time is between 8 am and 8 pm
                if (!(hour >= 8 && hour < 20 && minute >= 0 && minute <= 59)) {
                    throw new IncorrectActionException("Invalid time. Please choose a time between 8 am and 8 pm.");
                }
            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                throw new IncorrectActionException("Invalid time format. Please use HH:mm (24-hour format).");
            }
        }
    }
}
